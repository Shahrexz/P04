declare module 'react-native-web-maps' {
  const MapView: any;
  const Marker: any;
  const Polyline: any;
  export { MapView, Marker, Polyline };
}
