// controllers/authController.js
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Signup logic
exports.signup = async (req, res) => {
  const { username, email, password, role } = req.body;

  try {
    // Validate the role
    const validRoles = ['Customer', 'Hotel Management Staff', 'Car Rental Staff']; // Add more roles if needed
    if (!validRoles.includes(role)) {
      return res.status(400).json({ message: 'Invalid role specified' });
    }

    // Check if the user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already exists' });
    }

    // Create a new user (password is stored as plain text)
    const newUser = new User({
      username,
      email,
      password,  // No hashing here
      role
    });

    // Save the user in the database
    await newUser.save();

    // Respond with success
    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error creating user', error });
  }
};



/// Login logic without bcrypt
exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    console.log('Received login request:', { email, password });

    const existingUser = await User.findOne({ email });
    if (!existingUser) {
      console.log(`User with email ${email} not found`);
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    if (password !== existingUser.password) {
      console.log(`Password mismatch for user ${email}`);
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign(
      {
        email: existingUser.email,
        username: existingUser.username,
        role: existingUser.role,
        hotel_id: existingUser.hotel_id,
        car_rental_company_id: existingUser.car_rental_company_id,
      },
      'your_secret_key',
      { expiresIn: '1h' }
    );

    console.log(`Generated token for user ${email}`);

    res.status(200).json({
      message: 'Login successful',
      token,
      role: existingUser.role,
      hotel_id: existingUser.hotel_id
    });

  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ message: 'Error logging in', error });
  }
};