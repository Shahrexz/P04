/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/CarRentalInfo` | `/CarsManagement` | `/EditAccInfo` | `/EditCompanyDetails` | `/Login` | `/ReservationsRequest` | `/Routes/Routes` | `/_sitemap` | `/components/protectedroute` | `/contexts/authcontext` | `/styles` | `/styles/signupstyle`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
