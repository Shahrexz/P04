/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/EditAccInfo` | `/Edit_Room_Info` | `/Hotel Admin` | `/Login` | `/ReservationsRequest` | `/Routes/Routes` | `/_sitemap` | `/components/protectedroute` | `/contexts/authcontext` | `/styles` | `/styles/signupstyle`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
